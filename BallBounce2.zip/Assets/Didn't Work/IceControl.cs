//using UnityEngine;

//public class IceControl : MonoBehaviour
//{
//    public Rigidbody2D my_rb;
//    public GameObject iceBlock;
//    private bool Ice = false;
//    private void OnTriggerEnter2D(Collider2D other)
//    {
//        if (other.gameObject.tag == "Ice")
//        {
//            Ice = true;
//            my_rb.linearDamping = 0f;
//            Debug.Log("hi");
//        }
//        else
//        {
//            Ice = false;
//            my_rb.linearDamping = .5f;
//            Debug.Log("bye");
//        }
//    }
//}