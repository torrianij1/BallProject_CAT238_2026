using UnityEngine;

public class MovingPlatform : MonoBehaviour
//https://www.youtube.com/watch?v=GtX1p4cwYOc
{
    public float speed; //platform speed
    public int startingPoint; //position of platform
    public Transform[] points; //array of points platform moves to

    private int i; //index of array

    void Start()
    {
        transform.position = points[startingPoint].position;
    }

    void Update()
    {
        //checks distance of platform and the point
        if (Vector2.Distance(transform.position, points[i].position) < 0.02f)
        {
            i++; //increase index
            if (i == points.Length) //check if platform was on last point after index increase
            {
                i = 0; //reset index
            }
        }
        //move platform to points with index 'i'
        transform.position = Vector2.MoveTowards(transform.position, points[i].position, speed * Time.deltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        collision.transform.SetParent(transform);
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        collision.transform.SetParent(null);
    }
}
