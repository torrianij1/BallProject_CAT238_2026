using UnityEngine;

public class BallMovementScript : MonoBehaviour
{
    private float moveSpeed = 12.5f;
    private float jumpForce = 17.5f;
    public GameObject playerBall;
    public Rigidbody2D my_rb;

    //public bool onGround = true;
    bool grounded;
    public Vector2 boxSize;
    public float castDistance;
    public LayerMask groundLayer;

    public KeyCode movingLeft;
    public KeyCode movingRight;
    public KeyCode jump;
    public KeyCode gravityJump;

    void Start()
    {
        my_rb = GetComponent<Rigidbody2D>();
        jump = KeyCode.UpArrow;
    }

    void Update() //impulse movements like jumping
    {
        if (Input.GetKeyDown(jump) && IsGrounded() || Input.GetKeyDown(KeyCode.Space) && IsGrounded())
        {
            PlayerBallJump();
        }
        if (Input.GetKeyDown(gravityJump) && IsGrounded())
        {
            my_rb.AddForce(Vector2.down * jumpForce, ForceMode2D.Impulse);
        }
    }

    void FixedUpdate() //continuous movements like rolling
    {
        if (Input.GetKey(movingRight))
        {
            my_rb.AddForce(Vector2.right * moveSpeed);
            //Debug.Log("right input detected");
        }

        if (Input.GetKey(movingLeft))
        {
            my_rb.AddForce(Vector2.left * moveSpeed);
            //Debug.Log("left input detected");
        }


    }
    void PlayerBallJump()
    {
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        //Debug.Log("up input detected");
        //onGround = false;
    }

    public bool IsGrounded() //https://www.youtube.com/watch?v=P_6W-36QfLA
    {
        if (Physics2D.BoxCast(transform.position, boxSize, 0, -transform.up, castDistance, groundLayer))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    private void OnDrawGizmos()
    {
        Gizmos.DrawWireCube(transform.position - transform.up * castDistance, boxSize);
    }

    //private void OnCollisionEnter2D(Collision2D other) //https://www.youtube.com/watch?v=oR44qY0tWPc
    //{
    //    if (other.gameObject.tag == "Floor")
    //    {
    //        Vector3 normal = other.GetContact(0).normal;
    //        if (normal == Vector3.up)
    //        {
    //            onGround = true;
    //        }
    //    }
    //}
    //private void OnCollisionExit2D(Collision2D other) 
    //{
    //    if (other.gameObject.tag == "Floor")
    //    {
    //        onGround = false;
    //    }
    //}
}
