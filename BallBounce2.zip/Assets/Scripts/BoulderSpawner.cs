using UnityEngine;

public class BoulderSpawner : MonoBehaviour //https://www.youtube.com/watch?v=1h2yStilBWU
{
    public GameObject boulders;
    public bool stopSpawning = false;
    public float spawnTime;
    public float spawnDelay;

    void Start()
    {
        InvokeRepeating("SpawnObject", spawnTime, spawnDelay);
    }
    public void SpawnObject()
    {
        Instantiate(boulders, transform.position, transform.rotation);
        if (stopSpawning)
        {
            CancelInvoke("SpawnObject");
        }
    }
}
