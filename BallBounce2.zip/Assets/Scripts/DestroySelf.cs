using UnityEngine;

public class DestroySelf : MonoBehaviour
{
    public GameObject destroyObject;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Destroy(destroyObject, 10f); //https://www.youtube.com/watch?v=EGQWlfT21FA
    }
}
