using UnityEngine;

public class FreezeRotation : MonoBehaviour
{
    private Quaternion initialRotation;
    void Start()
    {
        // Save the rotation you want to keep
        initialRotation = transform.rotation;
    }

    void LateUpdate()
    {
        // Force the rotation back to the initial value
        transform.rotation = initialRotation;
    }
}
