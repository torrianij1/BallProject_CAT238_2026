using UnityEngine;

public class BallButtonSafeRemove : MonoBehaviour
//used respawn controller as a base, then asked googleAI why certain parts didn't work
{
    public GameObject objectToDisable;
    public GameObject objectToDisablebutton;

    public string targetTag = "Player";

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag(targetTag))
        {
            if (objectToDisable != null)
            {
                objectToDisable.SetActive(false);
                objectToDisablebutton.SetActive(false);
            }
        }
    }
}