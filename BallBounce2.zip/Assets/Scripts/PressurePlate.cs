using UnityEngine;

public class PressurePlate : MonoBehaviour
//https://www.youtube.com/watch?v=Gx3F8SSorlg
{
    public Vector3 originalPos;
    bool moveBack = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        originalPos = transform.position;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            collision.transform.parent = transform;
            GetComponent<SpriteRenderer>().color = Color.darkCyan;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            transform.Translate(0, -.05f, 0);
            moveBack = false;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        collision.transform.parent = null;
        GetComponent<SpriteRenderer>().color = Color.cyan;
        moveBack = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (moveBack)
        {
            if (transform.position.y < originalPos.y)
            {
                transform.Translate(0, .025f, 0);
            }
            else
            {
                moveBack = false;
            }
        }
    }
}
