using UnityEngine;

public class MusicController : MonoBehaviour
//https://www.youtube.com/watch?v=c2c-x79PPXw
//had to eventually use chatGPT to add the bool and array to stop music from overlapping
//it was actually driving me crazy
{
    public AudioSource myAudio;

    public AudioClip[] myAudioClips;
    private bool hasStarted = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        RandomTrack();
    }
    void Update()
    {
        if (hasStarted && !myAudio.isPlaying)
        {
            RandomTrack();
        }
    }
    void RandomTrack()
    {
        AudioSource[] sources = FindObjectsByType<AudioSource>(FindObjectsSortMode.None);

        foreach (AudioSource source in sources)
        {
            source.Stop();
        }
        float Roll = Random.value;

        if (Roll <= .5f)
        {
            myAudio.clip = myAudioClips[0];
            Debug.Log(Roll);
        }
        if (Roll > .51f)
        {
            myAudio.clip = myAudioClips[1];
            Debug.Log(Roll);
        }
        myAudio.Play();
        hasStarted = true;
    }
}
