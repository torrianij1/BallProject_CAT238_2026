using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartGame : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.R)) //whenever R is pressed
        {
            RestartingGame(); //Restarts game using custom function
        }
    }
    void RestartingGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); //loads scene 0
        //Debug.Log("restarting game");
    }
}
