using UnityEngine;
using UnityEngine.SceneManagement;

public class UpDownSpikes : MonoBehaviour
//https://www.youtube.com/watch?v=ErajgMCsTH8
{
    Rigidbody2D my_rb;
    BoxCollider2D boxCollider2D;
    public float distance;
    public float spikeSpeed;
    bool isFalling = false;

    private void Start()
    {
        my_rb = GetComponent<Rigidbody2D>();
        boxCollider2D = GetComponent<BoxCollider2D>();
    }

    private void Update()
    {
        Physics2D.queriesStartInColliders = false;
        if (isFalling == false)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.up, distance);
            Debug.DrawRay(transform.position, Vector2.up * distance, Color.red);

            if (hit.transform != null)
            {
                if (hit.transform.tag == "Player")
                {
                    my_rb.AddForce(Vector2.up * spikeSpeed, ForceMode2D.Impulse);
                    //my_rb.gravityScale = 5;
                    isFalling = true;
                }
            }
        }
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Floor")
        {
            Destroy(gameObject);
        }
        else
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}