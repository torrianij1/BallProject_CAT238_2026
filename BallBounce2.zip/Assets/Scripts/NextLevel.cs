using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{
    public int level;
    void OnCollisionEnter2D(Collision2D other)//custom function to detect collision to switch scenes
    {
        if (other.gameObject.tag == "Player")
        {
            //Debug.Log("collision detected"); //detects when object is touched
            SceneManager.LoadScene("Level " + (level + 1)); //loads scene 
        }
    }
}
