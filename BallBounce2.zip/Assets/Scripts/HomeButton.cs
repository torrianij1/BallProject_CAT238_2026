using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class HomeButton : MonoBehaviour
{
    public void HomeButtonClick()
    {
        SceneManager.LoadScene(0);
        //Debug.Log("entering level selection screen");
    }
}