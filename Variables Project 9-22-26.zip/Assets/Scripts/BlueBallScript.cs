using UnityEngine;

public class BlueBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject blueBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh. Hello there. BlueBallScript is starting.");
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.D))
        {
            Debug.Log("d key pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            Debug.Log("a key pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            Debug.Log("w key pressed");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }

    }
}
