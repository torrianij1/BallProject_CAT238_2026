using UnityEngine;

public class PinkBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject pinkBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //Debug.Log("Oh. Hello there. PinkBallScript is starting.");
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.L))
        {
            Debug.Log("l key pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            Debug.Log("j key pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.I))
        {
            Debug.Log("i key pressed");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }

    }
}
