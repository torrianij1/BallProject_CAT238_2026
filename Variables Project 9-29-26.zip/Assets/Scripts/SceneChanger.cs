using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChanger : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D other)//custom function to detect collision to switch scenes
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected"); //detects when object is touched
            SceneManager.LoadScene(1); //loads scene 1
        }
    }
}
