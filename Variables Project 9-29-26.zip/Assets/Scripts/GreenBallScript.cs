using UnityEngine;

public class GreenBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject greenBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //Debug.Log("Oh. Hello there. GreenBallScript is starting.");
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            //Debug.Log("right arrow key pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            //Debug.Log("left arrow key pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.UpArrow)||(Input.GetKeyDown(KeyCode.Space)))
        {
            //Debug.Log("up arrow key pressed");
            GreenBallJump();
        }
    }
    void GreenBallJump()
    {
        //Debug.Log("first custom function");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
