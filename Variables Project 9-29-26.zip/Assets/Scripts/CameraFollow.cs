using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform followObject;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 currentPosition = transform.position;
        //Calculates angle to direct camera based on current position, locks height to specific x
        currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);
        currentPosition.z = -10; //Makes sure camera is on right layer
        transform.position = currentPosition; //Set position of camera equal to player location
    }
}
