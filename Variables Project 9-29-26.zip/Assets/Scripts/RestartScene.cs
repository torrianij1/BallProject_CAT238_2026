using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartScene : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.R)) //whenever R is pressed
        {
            RestartGame(); //Restarts game using custom function
        }
    }

    void RestartGame()
    {
        SceneManager.LoadScene(0); //loads scene 0
    }

}
