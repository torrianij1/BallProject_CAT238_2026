using UnityEngine;
using Unity.VisualScripting;

public class CheckpointManager : MonoBehaviour
//https://www.youtube.com/watch?v=VtbHjGcsXLE
//edited by asking google ai because the original wasn't working
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            // Find the RespawnController on the player or in the scene once per trigger event
            RespawnController respawn = FindFirstObjectByType<RespawnController>();

            if (respawn != null)
            {
                respawn.respawnPoint = this.gameObject;
            }
        }
    }
}