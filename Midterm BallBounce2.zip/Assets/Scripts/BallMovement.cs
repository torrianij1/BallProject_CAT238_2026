using UnityEngine;

public class BallMovementScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject playerBall;
    public Rigidbody2D my_rb;
    public bool onGround = true;

    void Start()
    {
        my_rb = GetComponent<Rigidbody2D>();
    }

    void Update() //impulse movements like jumping
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) && onGround == true||Input.GetKeyDown(KeyCode.Space) && onGround == true)
        {
            PlayerBallJump();
        }
    }

    void FixedUpdate() //continuous movements like rolling
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            my_rb.AddForce(Vector2.right * moveSpeed);
            //Debug.Log("right input detected");
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            my_rb.AddForce(Vector2.left * moveSpeed);
            //Debug.Log("left input detected");
        }
    }
    void PlayerBallJump()
    {
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        //Debug.Log("up input detected");
        onGround = false;
    }
    private void OnCollisionEnter2D(Collision2D collision) //https://www.youtube.com/watch?v=oR44qY0tWPc
    {
        if(collision.gameObject.tag == "Floor")
        {
            onGround = true;
        }
    }
}
