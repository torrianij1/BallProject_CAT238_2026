using UnityEngine;

public class SwipeController : MonoBehaviour //https://www.youtube.com/watch?v=qf9xe2mbWeU
{
    public int maxPage;
    int currentPage;
    Vector3 targetPos;
    public Vector3 pageStep;
    public RectTransform levelPagesRect;

    public float tweenTime;
    public LeanTweenType tweenType;

    private void Start()
    {
        currentPage = 1;
        targetPos = levelPagesRect.localPosition;
    }
    public void Next()
    {
        if (currentPage < maxPage)
        {
            currentPage++;
            targetPos += pageStep;
            MovePage();
        }
    }

    public void Previous()
    {
        if (currentPage > 1)
        {
            currentPage--;
            targetPos -= pageStep;
            MovePage();
        }
    }    

    void MovePage()
    {
        levelPagesRect.LeanMoveLocal(targetPos, tweenTime).setEase(tweenType);
    }
}
