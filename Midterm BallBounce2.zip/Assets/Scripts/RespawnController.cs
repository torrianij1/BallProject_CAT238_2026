using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RespawnController : MonoBehaviour //https://www.youtube.com/watch?v=VtbHjGcsXLE
{
    public GameObject playerBall;
    public GameObject respawnPoint;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            playerBall.transform.position = respawnPoint.transform.position;
            Rigidbody2D rb = playerBall.GetComponent<Rigidbody2D>();
            if (rb != null) //pauses movement when respawning
            {
                rb.linearVelocity = Vector2.zero;
                rb.angularVelocity = 0f;
            }
        }
    }
}
