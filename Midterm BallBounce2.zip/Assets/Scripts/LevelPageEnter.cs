using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class LevelPageEnter : MonoBehaviour
{
    public void StartGameButton()
    {
        SceneManager.LoadScene(1);
        //Debug.Log("entering level selection screen");
    }
}
