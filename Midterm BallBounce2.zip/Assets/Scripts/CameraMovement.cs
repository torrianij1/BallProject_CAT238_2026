using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform followObject;

    // Update is called once per frame
    void Update()
    {
        Vector3 currentPosition = transform.position;
        //Calculates angle to direct camera based on current position, locks height to specific x
        currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);
        currentPosition.y = Mathf.Lerp(currentPosition.y, followObject.position.y, .5f);
        currentPosition.z = -10; //Makes sure camera is on right layer
        transform.position = currentPosition; //Set position of camera equal to player location
    }
}